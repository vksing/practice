package demo;

import org.testng.annotations.Test;

public class fish {
	@Test
	  public void flown() {
		  System.out.println("hello.....");
	  }

}
