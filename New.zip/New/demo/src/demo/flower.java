package demo;

import org.testng.annotations.Test;

public class flower {
	@Test
	  public void flew() {
		  System.out.println("hoooooo.....");
	  }

}
