package mfrp1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class mfrppr1 {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		FileInputStream fil= new FileInputStream("D:\\selenium\\apa.xlsx");		
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		XSSFSheet sheet =workbook.getSheetAt(0);
		int  rowcount = sheet.getLastRowNum();
		System.out.println(rowcount);
		for(int i=1; i<=rowcount;i++)
		{
			XSSFRow row =sheet.getRow(i);
			XSSFCell cell= row.getCell(0);
			String fromDestination= cell.getStringCellValue();
			XSSFCell cell1=row.getCell(1);
			String toDestination=cell1.getStringCellValue();
		
		// TODO Auto-generated method stub
		System.out.println(fromDestination);
	System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.savaari.com/");
		
			
		driver.manage().window().maximize();
		if(driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
				+ "app-home/div[1]/div[2]/div[1]/div[1]/a/span")).isEnabled())
		{
			driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
					+ "app-home/div[1]/div[2]/div[1]/div[1]/a/span")).click();
			
		//button
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
				+ "app-home/div[1]/div[2]/div[2]/app-outstation/div/div/div/label[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"fromCityList\"]")).sendKeys(fromDestination);
		Thread.sleep(1000);
		// from destination tabkeys
		driver.findElement(By.xpath("//*[@id=\"fromCityList\"]")).sendKeys(Keys.TAB);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/"
				+ "div[1]/div[2]/div[2]/app-outstation/div/form/div[2]/div[2]/input")).sendKeys(toDestination);
		Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
					+ "app-home/div[1]/div[2]/div[2]/app-outstation/"
				+ "div/form/div[2]/div[2]/input")).sendKeys(Keys.TAB);
	//nn
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
				+ "app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/"
				+ "div[1]/div/p-calendar[1]/span/input")).click();
		//nn
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/"
			+ "div[2]/div[2]/app-outstation/div/form/div[3]/"
			+ "div[1]/div/p-calendar[1]/span/div/table/tbody/tr[4]/td[5]/a")).click();
	Thread.sleep(1000);
	///nn
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/"
			+ "app-outstation/div/form/div[3]/div[3]/div/p-calendar[1]/span/input")).click();
	
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/"
			+ "div[2]/app-outstation/div/form/div[3]/div[3]/div/p-calendar[1]/span/div/table/tbody/tr[5]/td[3]/a")).click();
	
	driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]")).click();

	WebElement ele= driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]"));
	Select sele = new Select (ele);
	sele.selectByIndex(3);
Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/"
			+ "div[2]/div[2]/app-outstation/div/form/div[4]/div/div[1]/button")).click();
		}
		
		
		
		//driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-select-car/div[2]/div/div/div[1]/div[5]/div/button"))
		else{
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/"
				+ "div[2]/div[1]/div[2]/a/span")).click();
	driver.findElement(By.xpath("//*[@id=\"fromCityList\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"fromCityList\"]")).sendKeys(fromDestination);
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"fromCityList\"]")).sendKeys(Keys.TAB);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/"
			+ "div[1]/div[2]/div[2]/app-local/div/form/div[2]/div[2]/select")).click();
	WebElement ele1= driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/"
			+ "app-home/div[1]/div[2]/div[2]/app-local/div/form/div[2]/div[2]/select"));
	Select sele1 = new Select (ele1);
	sele1.selectByIndex(1);
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/"
			+ "div[2]/app-local/div/form/div[3]/div[1]/div/p-calendar[1]/span/input")).click();
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-local/div/"
			+ "form/div[3]/div[1]/div/p-calendar[1]/span/div/table/tbody/tr[5]/td[3]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]")).click();
		WebElement element= driver.findElement(By.xpath("//*[@id=\"pickUpTime\"]"));
		Select s= new Select(element);
		s.selectByIndex(5);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/"
				+ "div[1]/div[2]/div[2]/app-local/div/form/div[4]/div/div[1]/button")).click();
		}
		}}

}
