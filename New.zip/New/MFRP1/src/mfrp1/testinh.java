package mfrp1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class testinh {
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileInputStream fil= new FileInputStream("D:\\selenium\\apa.xlsx");
XSSFWorkbook workbook = new XSSFWorkbook(fil);
XSSFSheet sheet =workbook.getSheetAt(0);
int  rowcount = sheet.getLastRowNum();
System.out.println(rowcount);
for(int i=0; i<=rowcount;i++)
{
	XSSFRow row =sheet.getRow(i);
	XSSFCell cell= row.getCell(0);
	String firstName= cell.getStringCellValue();
	XSSFCell cell1=row.getCell(1);
	String lastName=cell1.getStringCellValue();
	XSSFCell cell2=row.getCell(2);
	String email=cell2.getStringCellValue();
	XSSFCell cell3=row.getCell(3);
	String mailing=cell3.getStringCellValue();
	XSSFCell cell4=row.getCell(4);
	String city=cell4.getStringCellValue();
	XSSFCell cell5=row.getCell(5);
	double postal=cell5.getNumericCellValue();
	int t=(int) postal;
	XSSFCell cell6=row.getCell(6);
	String password=cell6.getStringCellValue();

	
	
	
	System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("http://demo.borland.com/InsuranceWebExtJS/signup.jsf");
	driver.findElement(By.id("signup:fname")).sendKeys(firstName);
	driver.findElement(By.id("signup:lname")).sendKeys(lastName);
	driver.findElement(By.id("signup:email")).sendKeys(email);
	driver.findElement(By.id("signup:street")).sendKeys(mailing);
	driver.findElement(By.id("signup:city")).sendKeys(city);
	driver.findElement(By.id("signup:zip")).sendKeys(t+"");
	driver.findElement(By.id("signup:password")).sendKeys(password);
	
	driver.findElement(By.id("signup:signup")).click();
	
	
}


	}

}
