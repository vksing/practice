package pck;

import org.testng.annotations.Test;

public class t1 {
	 @Test
	  public void f1() {
		  System.out.println("t1");
	  }
}
