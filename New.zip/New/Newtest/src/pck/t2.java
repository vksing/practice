package pck;

import org.testng.annotations.Test;

public class t2 {
	 @Test
	  public void f2() {
		  System.out.println("t2");
	  }
}
