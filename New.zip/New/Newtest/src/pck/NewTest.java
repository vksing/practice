package pck;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  System.out.println("main");
  }
}
