package selenium;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest3 {
	@Test(priority=1,description="DESCRIPTION")
	@BeforeMethod
	public void  test2()
	{
		System.out.println("before method");
	}
}
