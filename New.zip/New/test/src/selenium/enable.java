package selenium;

public @interface enable {

}
