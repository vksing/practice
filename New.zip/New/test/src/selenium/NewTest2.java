package selenium;

import org.testng.annotations.Test;

public class NewTest2 {
	@Test
	public void hello()
	{
		System.out.println("hello");
		
	}
}
