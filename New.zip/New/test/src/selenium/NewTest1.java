package selenium;

import org.testng.annotations.Test;

public class NewTest1 {
	@Test(enabled=true)
	public void testLogin()
	{
		try{
			int a=6/0;
			
		}
		catch(Exception e)
		{
			System.out.println("Invalid Input");
		}
	}
}
