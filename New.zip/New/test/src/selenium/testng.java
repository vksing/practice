package selenium;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class testng {

@Test(enabled=true)
public void testLogin()
{
	try{
		int a=6/0;
		
	}
	catch(Exception e)
	{
		System.out.println("Invalid Input");
	}
}
@Test
public void hello()
{
	System.out.println("hello");
	
}
@Test(priority=1,description="DESCRIPTION")
@BeforeMethod
public void  test2()
{
	System.out.println("before method");
}

@Test(priority=2,enabled=true)
@AfterMethod
public void regis()
{
	System.out.println("After method");
}
@Test( priority=3, dependsOnMethods={"testLogin"})
public void depend()
{
	System.out.println("dependent one");
	
}
}
