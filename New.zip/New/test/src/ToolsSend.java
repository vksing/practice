import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class ToolsSend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();	
		driver.get("https://github.com/");
		List<WebElement> lis= driver.findElements(By.xpath("//input [@type='text']"));
		for(int i=0;i<lis.size();i++)
		{
			lis.get(i).sendKeys("mohan");
		}
		

	}

}
