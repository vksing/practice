
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;




	public class Toolsqa {
	public static void main(String[] args) throws Exception
	{
//		
//		System.setProperty("Webdriver.ie.driver","D:/694816/Ie/IE Driver/IEDriverServer_Win32_3.12.0I");
//		WebDriver driver=new  InternetExplorerDriver();
//		driver.get("http://jqueryui.com");
//		driver.findElement(By.linkText("Download")).click();
//		driver.findElement(By.linkText("Development")).click();
//		driver.navigate().back();
//		driver.navigate().forward();
//		driver.navigate().refresh();
				
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("http://jqueryui.com");
		driver.findElement(By.linkText("Droppable")).click();
		driver.switchTo().frame(0)
	;
		
		WebElement ele1=driver.findElement(By.id("draggable"));
		WebElement ele2 = driver.findElement(By.id("droppable"));
		Actions act =new Actions(driver);
		act.dragAndDrop(ele1, ele2).build().perform();
		File src = (((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE));
		FileUtils.copyFile(src,new File("D:\\New\\test\\seleniumfailedTC\\error.png"));
	
//	WebElement ele= driver.findElement(By.id("continents"));
//	Select sele = new Select (ele);
//	sele.selectByIndex(3);
//	WebElement ele1=driver.findElement(By.id("selenium_commands"));
//	Select sele1= new Select (ele1);
//	sele1.selectByIndex(2);
	
	
	//driver.manage().window().maximize();
	}
	} 