import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class Internet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.ie.driver", "D:\\694816\\Ie\\IE Driver\\IEDriverServer_x64_3.12.0\\IEDriverServer.exe");
		//System.setProperty("webdriver.ie.driver","D:\\694816\\Ie\\IE Driver\\IEDriverServer_x64_3.12.0\\IEDriverServer.exe>");
		WebDriver driver=new InternetExplorerDriver();
		driver.get("http://jqueryui.com");
	}

}
