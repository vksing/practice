import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class sell {
public static void main(String[] args) throws Exception
{
	System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("http://www.aeon.co");
}
} 