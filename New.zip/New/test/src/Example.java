import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


	public class Example {
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.github.com");
		String s=driver.getPageSource();
		System.out.println(s);;
		driver.findElement(By.linkText("Sign in")).click();

		driver.findElement(By.id("login_field")).sendKeys("vksing");
		driver.findElement(By.id("password")).sendKeys("github@1234");
		driver.findElement(By.name("commit")).click();
		//driver.findElement(By.xpath("//*[@id=signin_info]/a[1]")).click(); 
	driver.manage().window().maximize();
	}
	} 