import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class SwitchWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:\\selenium\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();	
		driver.get("https://toolsqa.wpengine.com/automation-practice-switch-windows/");
		String handle = driver.getWindowHandle();
		System.out.println(handle);
		driver.findElement(By.xpath("//*[@id='content']/p[3]/button")).click();
		Set<String> handles = driver.getWindowHandles();
		System.out.println(handles);
		for( String handle1 : driver.getWindowHandles())
		{
			System.out.println(handle1);
			driver.switchTo().window(handle1);
			driver.close();		
		
		}
		driver.quit();
	}

}
